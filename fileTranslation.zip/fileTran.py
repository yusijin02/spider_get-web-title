# 将原文件分解为多个小文件，以便多线程处理以及
import pandas as pd
import time

print("[{}]".format(time.strftime("%H:%M:%S", time.localtime())) + "[INFO]" + "Script fileTran.py gets started.")
originFile = pd.read_excel("./resource/URL.xlsx")
N = 450176
n = 0
try:
    for i in range(50):
        print("[{}]".format(time.strftime("%H:%M:%S", time.localtime())) + "[INFO]" + "Processing {}/50 files.".format(
            i + 1))
        with open("./result/url{}.txt".format(i), 'w', encoding='utf-8') as urlFile:
            for j in range(n, min((i + 1) * 9004, N)):
                data = originFile.values[j, 0]
                urlFile.write(data + '\n')
            n = j
except Exception as e:
    # 异常处理
    text = "[{}]".format(time.strftime("%H:%M:%S", time.localtime())) + "[ERROR]" + e.__str__()
    print(text)
    with open("./log/fileErrorLog.txt", 'a', encoding='utf-8') as logFile:
        logFile.write(text + '\n')
